$(function(){
   $(".hexa-parent").click(function(){
        $(".hexa-parent,.hexa-parent p").addClass("hide");
        $(this).removeClass("hide");
        $(this).next(".hexa-detail").removeClass("hide");
       
   })
           
    $(".hex-container").mouseleave(function(){
       $(".hexa-parent,.hexa-parent p").removeClass("hide");
       $(".hexa-detail").addClass("hide");
   });
   
       
   
});